<nav class="topnav">
      <?php 
    if(isset($_SESSION['userid'])){?>
    <a class="active" href="index.php">Home</a>
    
    <a href="comments.php">Comments</a>
    <a href="appointment.php">Appointment</a>
     
    <a href="settings.php">settings</a>
  
     
        <?php     echo '<a href="users.php">Users</a>';  }
    ?>
    
  

</nav>
