<?php
session_start();
if(!isset($_SESSION["ID_admin"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
     if($_POST['do']=="update"){
         $id = $_POST["id"];
 
         $doctorId   = $_POST['doctorId'];
         $date      = $_POST['date'];
         $accepted=$_POST['accepted'];
     $stmt = $con->prepare("UPDATE appointment SET 
                                    doctorId = ?,
                                    date = ?,accepted=?
                            WHERE appointmentId = ?");
    $stmt->execute(array($doctorId, $date,$accepted, $id));
}
if($_POST['do']=="add"){
    $formErrors = array();

    $userId   = $_POST['userId'];
    $doctorId   = $_POST['doctorId'];
    $date      = $_POST['date'];


 

    if(empty($formErrors)){

            // Insert Userinfo Into Database

            $stmt = $con->prepare("INSERT INTO 
                                        appointment(userId, `doctorId`, date,accepted)
                                    VALUES(:userId, :doctorId, :date,1)");
            $stmt->execute(array(
                'userId'  => $userId,
                'doctorId'  => $doctorId,
                'date'  => $date
           
            ));

            //Echo Success Message

                     

    

    }

}
if($_POST['do']=="delete"){
    $id = $_POST["id"];

    $stmt = $con->prepare("DELETE from  appointment  WHERE appointmentId = ?");
   $stmt->execute(array( $id));
}


 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>appointment</title>
     <script src="https://kit.fontawesome.com/ec292494c9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        body {
            background-image: url('Mass Circles.svg');
        }
    </style>
</head>
<body>


<?php  include('navbar.php'); 
$stmt = $con->prepare("SELECT a.*,p.firstName,p.lastName  FROM `appointment` a join patient p on p.userId=a.userId join patient d on d.userId=a.doctorId; ");
$stmt->execute( );
$rows = $stmt->fetchAll();
$stmt = $con->prepare("SELECT * FROM `patient` where isAdmin = 2   ");
$stmt->execute( );
$doctors = $stmt->fetchAll();
$stmt = $con->prepare("SELECT * FROM `patient` where isAdmin = 0 ");
$stmt->execute( );
$patients = $stmt->fetchAll();
?>
<h1></h1>
<br><br>
<div class="profile_form" style="width: 90%; margin: 50px auto;">
 <h1 style="text-align: center;">list of appointments</h1>
<div class="table-responsive">
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div>
  <table class="table" border="1" style="margin: auto; width: 80%;">
    <thead>
<tr>
    <th>id</th>
    <th>first name</th>
    <th>last name</th>
    <th>Doctor</th>
 
    <th>Date</th>
   <th>Statu</th>
    <th>Update</th>
    <th>Delete</th>
</tr>
    </thead>
    <tbody>
<?php foreach ($rows as $row) {?>
    <tr>
        <form action="" method="post">
<input type="hidden" name="do" value="update">

<input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">
    <td><?php echo $row['appointmentId'] ?></td>
    <td><?php echo $row['firstName'] ?></td>
    <td><?php echo $row['lastName'] ?></td>
    <td>
<select name="doctorId"  >
<?php foreach ($doctors as $doc ) {?>
    <option value="<?php echo $doc['userId'] ?>"<?php if($row['doctorId']==$doc['userId']) echo 'selected' ?> ><?php echo $doc['firstName'].' '.$doc['lastName'] ?></option>
<?php }?>

</select> 
<td><input type="date" name="date" id="date" value="<?php echo $row['date'] ?>">
    </td>       
</td>
   
<td>
<select name="accepted"  >
<option value="0">In Hold</option>
<option value="1" <?php if($row['accepted']==1)echo 'selected' ?>>Approve</option>
<option value="2" <?php if($row['accepted']==2)echo 'selected' ?>>Denied</option>

</select>  </td>   
    <td><button type="submit"  >UPDATE</button></td>
 </form>
 <form action="" method="post">
 <input type="hidden" name="do" value="delete">
 <input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">
     <td><button type="submit"  >DELETE</button></td>
 </form>
</tr>
    <?php } ?>
    </tbody>
  </table>
</div>
  
<div class="form">
<h1  style="text-align: center;">add new appointment</h1>
            <div class="content" style="border: 1px solid black;">
          
                

                <form class="sign-up" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <input type="hidden" name="do" value="add">
                <label for="date">Date <abbr title="This field is required" aria-label="required">*</abbr></label> 
                 <input type="date" name="date" id="date" required><br><br>
                    <label for="doctorId">doctor <abbr title="This field is required" aria-label="required">*</abbr></label> 
                    <select name="doctorId" id="doctorId"  >
<?php foreach ($doctors as $doc ) {?>
    <option value="<?php echo $doc['userId'] ?>" ><?php echo $doc['firstName'].' '.$doc['lastName'] ?></option>
<?php }?>

</select> <br>
<br>
<label for="doctorId">patient <abbr title="This field is required" aria-label="patient">*</abbr></label> 
                    <select name="userId" id="userId"  >
<?php foreach ($patients as $pat ) {?>
    <option value="<?php echo $pat['userId'] ?>" ><?php echo $pat['firstName'] ?> <?php echo $pat['lastName'] ?> </option>
<?php }?>

</select> <br>
                    <div class="btns">
                        <input type="submit" id="sign-up" name="signup" class="btn" value="Add">
                    </div>
                </form>
            </div>
        </div>
</div>

         


<!--footer-->


 



        <h3><span></span></h3>
 



<?php include('footer.php'); ?>


</body>
</html>