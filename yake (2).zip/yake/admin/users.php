<?php
session_start();
if(!isset($_SESSION["ID_admin"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
     if($_POST['do']=="update"){
         $id = $_POST["id"];
 
     $firstname     = $_POST['firstName'];
     $lastname      = $_POST['lastName'];
     $email      = $_POST['email'];
     $phone      = $_POST['phone'];
     $gender      = $_POST['gender'];
     $address     = $_POST['address'];
     $pirthDate      = $_POST['pirthdate'];
     $isAdmin      = $_POST['isAdmin'];
     $stmt = $con->prepare("UPDATE patient SET 
                                    email = ?,
                                    firstName = ?,
                                    lastName = ?,
                                    phoneNum = ?,
                                    gender = ?,
                                    pirh_date = ?,
                                    isAdmin=?,
                                    address=?
                            WHERE userId = ?");
    $stmt->execute(array($email, $firstname, $lastname, $phone, $gender, $pirthDate,$isAdmin,$address,$id));
}
if($_POST['do']=="add"){
    $formErrors = array();

    $firstname   = $_POST['firstname'];
    $lastname   = $_POST['lastname'];
    $email      = $_POST['email'];
    $password   = $_POST['password'];
    $password2  = $_POST['confirmpassword'];
    $address  = $_POST['address'];
    $phone  = $_POST['phone'];
    $gender  = $_POST['gender'];
    $pirthDate  = $_POST['pirthDate'];
    $isAdmin      = $_POST['isAdmin'];
    $Specialization      = $_POST['Specialization'];
    if(isset($firstname)){

        $filterUser = filter_var($firstname, FILTER_SANITIZE_STRING);

        if(strlen($filterUser) < 4){

            $formErrors [] = 'first name Must Be Lager Than 4 Characters';

        }

    }

    if(isset($lastname)){

        $filterUser = filter_var($lastname, FILTER_SANITIZE_STRING);

        if(strlen($filterUser) < 5){

            $formErrors [] = 'last name Must Be Lager Than 5 Characters';

        }

    }

    if(isset($password) && isset($password2)){

        if(empty($password)){

            $formErrors[] = 'Sorry Password Cant Be Empty ';

        }

        if(sha1($password) !== sha1($password2)){

            $formErrors[] = 'Sorry Password Is Not Match';

        }

    }

    if(isset($email)){

        $filterEmail = filter_var($email, FILTER_SANITIZE_EMAIL);

        if(filter_var($filterEmail, FILTER_VALIDATE_EMAIL) != true){

            $formErrors[] = 'Sorry This Email Is Not Valid';

        }

    }
    if(isset($address)){

        $filterUser = filter_var($address, FILTER_SANITIZE_STRING);

        if(strlen($filterUser) < 5){

            $formErrors [] = 'address Must Be Lager Than 5 Characters';

        }

    }
    if(isset($phone)){

        $filterUser = filter_var($phone, FILTER_SANITIZE_STRING);

        if(strlen($filterUser) < 5){

            $formErrors [] = 'Phone Must Be Lager Than 5 Characters';

        }

    }

    if(empty($formErrors)){

            // Insert Userinfo Into Database

            $stmt = $con->prepare("INSERT INTO 
                                        patient(email, `password`, firstName, lastName, `address`, `phoneNum`,pirh_date,gender,isAdmin,Specialization)
                                    VALUES(:zemail, :zpass, :zfirst, :zlast, :zaddress, :zphone, :pirh_date, :gender,:isAdmin,:Specialization)");
            $stmt->execute(array(
                'zemail'  => $email,
                'zpass'  => sha1($password),
                'zfirst'  => $firstname,
                'zlast'  =>  $lastname,
                'zaddress'  =>  $address,
                'zphone'  =>  $phone ,
                 'pirh_date'  =>  $pirthDate,
                'gender'  =>  $gender,'isAdmin'=>$isAdmin,'Specialization'=>$Specialization
            ));

            //Echo Success Message

                     

    

    }

}
if($_POST['do']=="delete"){
    $id = $_POST["id"];

    $stmt = $con->prepare("DELETE from  patient  WHERE userId = ?");
   $stmt->execute(array( $id));
}


 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>USERS</title>
    <script type="text/javascript"> (function() { var css = document.createElement('link'); css.href = 'https://use.fontawesome.com/releases/v5.1.0/css/all.css'; css.rel = 'stylesheet'; css.type = 'text/css'; document.getElementsByTagName('head')[0].appendChild(css); })(); </script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="../Users.css">
    <style>
        body {
            background-image: url('Mass Circles.svg');
        }
    </style>
</head>
<body>


<?php  include('navbar.php');
$stmt = $con->prepare("SELECT * FROM patient ");
$stmt->execute( );
$rows = $stmt->fetchAll();
?>
<h1></h1>
<br><br>
 
 <h1 style="text-align: center;">list of users</h1>
 
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div><center>
<button type="button" class="btn   btn-outline-success" data-toggle="modal" data-target=".bd-example-modal-lg">add new user</button>
</center>
        <div style="height: 100%;">
            
        <?php foreach ($rows as $row) {?>
    <a href="user.php?id=<?php echo $row['userId']?>">
    <div class="Patient_card" style="height:100%;margin-bottom: 50px">
    <div class="cards">
        <div class="content">
            <div class="cardS">
                <?php $picture="";if($row['isAdmin']=="2")$picture = "../doctor.svg";else if($row['isAdmin']=="1")$picture = "../yake.png";  else if($row['isAdmin']=="0" &&$row['gender']=="male") $picture = "../undraw_male_avatar_323b.svg";
                else  $picture = "../undraw_female_avatar_w3jk.svg";?>
                <img class="Patient_pic" src="<?php echo $picture ?>" style="width: 60px;">
                <div class="info">
                    <label class="Title_name"><?php echo $row['firstName'] ?> <?php echo $row['lastName'] ?></label>
                </div>
            </div>

        </div>
    </div>
</div>     
 
</a>

 
    <?php } ?>
 
    </div>
 
  <!-- Large modal -->
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" id="myLargeModalLabel" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
    <div class="form">
 <div class="modal-header">
        <h5 class="modal-title">add new user</h5>
  
      </div>
            <div class="content" style="border: 1px solid black;">
          
                

                <form class="sign-up" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <input type="hidden" name="do" value="add">
                    <!-- accept name contains 3 and more char -->
                    <label >First Name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="firstname" class="form-input" minlength="3" required>
<br>
                    <!-- required -->
                    <label >Last name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="lastname" class="form-input" required>
                    <br>
                    <!-- required -->
                    <label >Email <abbr title="This field is required" aria-label="required">*</abbr> </label>
                    <input type="email" name="email" class="form-input" id="mail" required>
                    <br>
                    <!-- has pattern -->
                    <label for="password">Password <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="password" name="password" class="form-input" required>
                    <br>
                    <!-- matches password -->
                    <label for="confirmpassword">confirm password <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="password" name="confirmpassword" class="form-input"  required><br>
                    <!-- matches password -->
                    <label for="address">address <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="address" id="address" class="form-input" required><br>
                    <label for="address">pirth Date <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="date" name="pirthDate" id="pirthDate" class="form-input" required><br>
                    <!-- matches password -->
                    <label for="phone">phone Number <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="phone" id="phone" class="form-input" required><br>
                    <label for="gender">gender <abbr title="This field is required" aria-label="required">*</abbr></label> 
                      <select name="gender" id="gender" >
<option value="female">female</option>
<option value="male"  >male</option>
</select><br>
<label for="gender">role <abbr title="This field is required" aria-label="required">*</abbr></label> 
                      <select name="isAdmin" id="isAdmin" onchange="dothis()"  class="form-control" >
                      <option value="0">patient</option>
      
      <option value="1" >Admin</option>
      <option value="2"  >doctor</option>
</select><br>
<div style="display: none;" id="Specialization">
  <label for="gender">Specialization <abbr title="This field is required" aria-label="required">*</abbr></label> 
                    <input type="text" name="Specialization" id="Specialization" class="form-input"  ><br>
</div>
                  
<center>
                    <div class="btns align-center">
                        <input type="submit" id="sign-up" name="signup" class="btn btn-primary" class="btn" value="Add">
                    </div></center>
                </form>
            </div>
        </div>
    </div>
  </div>
</div>


<!--function for Specialization in users page check if the user is admin the Specialization will appears
if not will disappear
  -->
<script>
    function dothis(){
        var e = document.getElementById("isAdmin");
var strUser = e.value;
if(strUser==2){
document.getElementById('Specialization').style.display="";
}else
document.getElementById('Specialization').style.display="none";
    }
</script>








 

    <h3><span></span></h3>



    <?php

if(isset($_POST['question'])){
   if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $email = $_POST['email'];
    $message = $_POST['message'];
    $stmt = $con->prepare("INSERT INTO question(`date`, question, email)
                                       VALUES(now(), :zquestion, :zemail)");
   $stmt->execute(array('zquestion' => $message, 'zemail' => $email));
   }
}

?>
<br>
<br>
<footer class="footer-distributed">

   <div class="footer-left">

       <h3>Yake<span>System</span></h3>

       <p class="footer-links">
           <a href="HomePage.html">Home</a>
           ·
           <a href="Appointment.html">Appointment</a>
           ·
           <a href="patient.html">Patient</a>
           ·
           <a href="#">About</a>
           ·
           <a href="#">Contact</a>
       </p>
<?php
       require_once '../connect.php';
$stmt = $con->prepare("SELECT * FROM settings ");
$stmt->execute( );
$row = $stmt->fetch();
?>
       <div class="footer-icons">

           <a href="<?php echo $row['facebook']?>"><i class="fa fa-facebook"></i></a>
           <a href="<?php echo $row['twiter']?>"><i class="fa fa-twitter"></i></a>
           <a href="<?php echo $row['in_']?>"><i class="fa fa-linkedin"></i></a>
           <a href="<?php echo $row['git']?>"><i class="fa fa-github"></i></a>

       </div>

   </div>

   <div class="footer-right">

       <p>Contact Us</p>

       <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<input type="hidden" name="do">
           <input type="email" name="email" placeholder="Email">
           <textarea name="message" placeholder="Message"></textarea>
           <input type="submit" name="question" value="Send">

       </form>

   </div>
   <script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"  crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" crossorigin="anonymous"></script>  
</footer>
<style>
    .footer-distributed{
        position: relative;
    }
</style>

</body>
</html>