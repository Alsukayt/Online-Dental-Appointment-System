<?php
session_start();
if(!isset($_SESSION["ID_admin"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if($_POST['do']=="update"){
        $id = $_POST["id"];

        $doctorId   = $_POST['doctorId'];
      $accepted=$_POST['accepted'];
    $stmt = $con->prepare("UPDATE appointment SET 
                                   doctorId = ?,
                                   accepted=?
                           WHERE appointmentId = ?");
   $stmt->execute(array($doctorId, $accepted, $id));
}if($_POST['do']=="delete"){
    $id = $_POST["id"];

    $stmt = $con->prepare("DELETE from  appointment  WHERE appointmentId = ?");
   $stmt->execute(array( $id));
}
if($_POST['do']=="profile"){
    $id = $_POST["id"];
 
    $firstname     = $_POST['firstname'];
    $lastname      = $_POST['lastname'];
    $email      = $_POST['email'];
    $phone      = $_POST['phone'];
    $gender      = $_POST['gender'];
    $address     = $_POST['address'];
    $pirthDate      = $_POST['pirthdatex'];
    $isAdmin      = $_POST['isAdmin'];
    $University      = $_POST['University'];
    $whatsapp      = $_POST['whatsapp'];
    $zoom      = $_POST['zoom'];
    $map_link      = $_POST['map_link'];
    $Specialization      = $_POST['Specialization'];

    $price      = $_POST['price'];
$password = $_POST['password'];
if(!empty($password)){
    
    $stmt = $con->prepare("UPDATE patient SET 
                                   email = ?,
                                   firstName = ?,
                                   lastName = ?,
                                   phoneNum = ?,
                                   gender = ?,
                                   pirh_date = ?,
                                   isAdmin=?,
                                   address=?,
                                   University=?,
                                   whatsapp = ?,
                                   zoom = ?,
                                   map_link = ?,
                                   password = ?,
                                   Specialization=?,
                                   price=?
                           WHERE userId = ?");
   $stmt->execute(array($email, $firstname, $lastname, $phone, $gender, $pirthDate,$isAdmin,$address,$University,$whatsapp,$zoom,$map_link,sha1($password),$Specialization,$price, $id));

}else{
    $stmt = $con->prepare("UPDATE patient SET 
    email = ?,
    firstName = ?,
    lastName = ?,
    phoneNum = ?,
    gender = ?,
    pirh_date = ?,
    isAdmin=?,
    address=?,
    University=?,
    whatsapp = ?,
    zoom = ?,
    map_link = ?,
    Specialization=?,
    price=? 
WHERE userId = ?");
$stmt->execute(array($email, $firstname, $lastname, $phone, $gender, $pirthDate,$isAdmin,$address,$University,$whatsapp,$zoom,$map_link,$Specialization,$price, $id));
}
}
 


 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>USERS</title>
     <script src="https://kit.fontawesome.com/ec292494c9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

</head>
<body>


<?php  include('navbar.php'); 
$stmt = $con->prepare("SELECT * FROM patient where userId = ".$_GET['id']);
$stmt->execute( );
$rows = $stmt->fetch();
?>
<h1></h1>
<br><br>
<div class="profile_form">
 
<div class="table-responsive">
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div>
 
</div>
<style>
        .Appointment{
            width: 100%;
        
            /*  border: 2px solid red;*/
        margin-top: 50px;
            height: 300px;
            text-align: center;
        }
        .table{
            /* border: 1px solid black;
             border-collapse: collapse;
            width: 700px;
            margin-right: 500px;
            background-color: #fdfdfd;*/
            border-collapse: collapse;
            width: 100%;
            background-color: white;
            color: black;
        }
        .table th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .table tr:hover {
            background-color: #675EF3;
            color: white;}

        .Appointment h1{
            text-align: center;
        }
        body {
   
 
    background: url('../Mass Circles.svg') no-repeat;
    background-position: center;
    background-size: cover;
}
    </style>
<div class="form">
<h1  style="text-align: center;"> user info </h1>
            <div class="content" style="border: 1px solid black;">
          
                

                <form class="sign-up" action="<?php echo $_SERVER['PHP_SELF'] ?>?id=<?php echo $_GET['id']?>" method="POST">
                <input type="hidden" name="do" value="profile">
                <input type="hidden" name="id" value="<?php echo $_GET['id']?>">
                    <!-- accept name contains 3 and more char -->
                    <label >First Name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="firstname" value="<?php echo $rows['firstName'] ?>" class="form-input" minlength="3" required>
<br>
                    <!-- required -->
                    <label >Last name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="lastname" value="<?php echo $rows['lastName'] ?>" class="form-input" required>
                    <br>
                    <!-- required -->
                    <label >Email <abbr title="This field is required" aria-label="required">*</abbr> </label>
                    <input type="email" name="email" value="<?php echo $rows['email'] ?>" class="form-input" id="mail" required>
                    <br>
                    <!-- has pattern -->
                    <label for="password">Password <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="password" name="password"   class="form-input"  >
                    <br>
                  
                    <!-- matches password -->
                    <label for="address">address <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="address" value="<?php echo $rows['address'] ?>" id="address" class="form-input" required><br>
                    <label for="address">pirth Date <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="date" name="pirthdatex"  value="<?php echo $rows['pirh_date'] ?>"   class="form-input" required><br>
                    <!-- matches password -->
                    <label for="phone">phone Number <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="phone" value="<?php echo $rows['phoneNum'] ?>" id="phone" class="form-input" required><br>
                    <label for="gender">gender <abbr title="This field is required" aria-label="required">*</abbr></label> 
                      <select name="gender" id="gender" >
<option value="female" <?php if($rows['gender']=='female') echo 'selected' ?>>female</option>
<option value="male" <?php if($rows['gender']=='male') echo 'selected' ?>>male</option>
</select><br>  
<label for="gender">Role <abbr title="This field is required" aria-label="required">*</abbr></label> 
                      <select name="isAdmin" id="isAdmin" >
<option value="0" <?php $isadmin=$rows['isAdmin']; if($rows['isAdmin']==0) echo 'selected' ?>>Patient</option>
<option value="1" <?php if($rows['isAdmin']==1) echo 'selected' ?>>Admin</option>
<option value="2" <?php if($rows['isAdmin']==2) echo 'selected' ?>>Doctor</option>
</select><br>
<div style="<?php if($rows['isAdmin']!=2) echo 'display:none' ?>">

<label for="phone">University <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="University" value="<?php echo $rows['University'] ?>" id="phone" class="form-input" ><br>
                    <label for="phone">whatsapp <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="whatsapp" value="<?php echo $rows['whatsapp'] ?>" id="phone" class="form-input" ><br>
                    <label for="phone">zoom <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="zoom" value="<?php echo $rows['zoom'] ?>" id="phone" class="form-input" ><br>
                    <label for="phone">map_link <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="map_link" value="<?php echo $rows['map_link'] ?>" id="phone" class="form-input" ><br>
                    <label for="phone">Specialization <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="Specialization" value="<?php echo $rows['Specialization'] ?>"   class="form-input" ><br>
                    <label for="phone">price <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="price" value="<?php echo $rows['price'] ?>"   class="form-input" ><br>

                    </div>

                    <div class="btns">
                        <input type="submit" id="sign-up" name="signup" class="btn btn-primary" value="UPDATE">
                    </div>
                </form>
            </div>
        </div>
        <?php
        $var = ""; if($isadmin!=1){
        if($isadmin==0)$var = "userId";
        if($isadmin==2)$var = "doctorId";
        $stmt = $con->prepare("SELECT a.*,p.firstName,p.lastName  FROM `appointment` a join patient p on p.userId=a.userId join patient d on d.userId=a.doctorId where a.$var =  ".$_GET['id']);
$stmt->execute( );
$rows = $stmt->fetchAll();
$stmt = $con->prepare("SELECT * FROM `patient` where  isAdmin = 2 ");
$stmt->execute( );
$doctors = $stmt->fetchAll(); 
    ?>
        <h1 style="text-align: center;">List of appointments</h1>
        <table class="table" border="1" style="margin: auto; width: 80%;">
    <thead>
<tr>
    <th>id</th>
    <th>Patient name</th>
 
    <th>Doctor</th>
    <th>Date</th>
    <th>time</th>
   <th>statu</th>
    <th>Update</th>
    <th>Delete</th>
</tr>
    </thead>
    <tbody>
<?php foreach ($rows as $row) {?>
    <tr>
        <form action="" method="post">
<input type="hidden" name="do" value="update">

<input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">
    <td><?php echo $row['appointmentId'] ?></td>
    <td><?php echo $row['firstName'] ?> <?php echo $row['lastName'] ?></td>
 
    <td>
<select name="doctorId" class="form-control" >
<?php foreach ($doctors as $doc ) {?>
    <option value="<?php echo $doc['userId'] ?>"<?php if($row['doctorId']==$doc['userId']) echo 'selected' ?> ><?php echo $doc['firstName'].' '. $doc['lastName'] ?></option>
<?php }?>

</select> </td>
<td><?php echo date('Y-m-d', strtotime($row['date'])) ?></td>

<td> <?php echo date('H:i:s A', strtotime($row['date'])) ?>
    </td>           

   
   <td>
   <select name="accepted" class="form-control" >
<option value="0">in hold</option>
<option value="1" <?php if($row['accepted']==1)echo 'selected' ?>>approved</option>
<option value="2" <?php if($row['accepted']==2)echo 'selected' ?>>denied</option>

</select>
   </td>
   
    <td><button type="submit" class="btn btn-primary" >UPDATE</button></td>
 </form>
 <form action="" method="post">
 <input type="hidden" name="do" value="delete">
 <input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">
     <td><button type="submit" class="btn btn-primary"  >DELETE</button></td>
 </form>
</tr>
    <?php } ?>
    </tbody>
  </table><?php 
} ?>
</div>

         


<!--footer-->


 

    <div class="footer-left">

        <h3>Yake<span>System</span></h3>
 



<?php include('footer.php'); ?>


</body>
</html>