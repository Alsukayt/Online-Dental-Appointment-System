<?php
session_start();
if(!isset($_SESSION["ID_admin"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
 
if($_POST['do']=="Approve"){
    $id = $_POST["id"];

    $stmt = $con->prepare("UPDATE  comment set approve = 1  WHERE commentId  = ?");
   $stmt->execute(array( $id));
}
if($_POST['do']=="delete"){
    $id = $_POST["id"];

    $stmt = $con->prepare("DELETE from  comment  WHERE commentId  = ?");
   $stmt->execute(array( $id));
}


 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>appointment</title>
     <script src="https://kit.fontawesome.com/ec292494c9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        body {
            background-image: url('Mass Circles.svg');
        }
    </style>
</head>
<body>


<?php  include('navbar.php'); 
$stmt = $con->prepare("SELECT c.*,p.firstName,p.lastName,d.firstName as dfirstName,d.lastName as dlastName FROM `comment` c join patient d on d.userId = c.doctorId join patient p on p.userId = c.patientId; ");
$stmt->execute( );
$rows = $stmt->fetchAll();
?>
<h1></h1>
<br><br>
<div class="profile_form" style="width: 90%; margin: 50px auto;">
 <h1 style="text-align: center;">list of Comments</h1>
<div class="table-responsive">
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div>
  <table class="table" border="1" style="margin: auto; width: 80%;">
    <thead>
<tr>
    <th>id</th>
    <th>first name</th>
    <th>last name</th>
    <th>patient Name</th>
    <th>date</th>
    <th>Doctor</th>
    <th>comment</th>
 
    <th>Approve</th>
    <th>Delete</th>
</tr>
    </thead>
    <tbody>
<?php foreach ($rows as $row) {?>
    <tr>
        <form action="" method="post">
<input type="hidden" name="do" value="Approve">

<input type="hidden" name="id" value="<?php echo $row['commentId'] ?>">
    <td><?php echo $row['commentId'] ?></td>
    <td><?php echo $row['firstName'] ?></td>
    <td><?php echo $row['lastName'] ?></td>
    <td><?php echo $row['patientName'] ?></td>
    <td><?php echo $row['date'] ?></td>
    <td><?php echo $row['dfirstName'].' '.$row['dlastName'] ?></td>
    <td><?php echo $row['comment'] ?></td>
  
 
    <td> <?php if ($row['approve']==0){?> <button type="submit"  >Approve</button><?php } ?></td>
 </form>
 <form action="" method="post">
 <input type="hidden" name="do" value="delete">
 <input type="hidden" name="id" value="<?php echo $row['commentId'] ?>">
     <td><button type="submit"  >DELETE</button></td>
 </form>
</tr>
    <?php } ?>
    </tbody>
  </table>
</div>
  
 
</div>

         


<!--footer-->


<footer class="footer-distributed">



        <h3><span></span></h3>
 



<?php include('footer.php'); ?>


</body>
</html>