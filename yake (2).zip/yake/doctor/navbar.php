<nav class="topnav">
      <?php 
    if(isset($_SESSION['userid'])){?>
    <a class="active" href="index.php">Home</a>
    
 
    <a href="appointment.php">Appointment</a>
    <a href="calendar.php">calendar</a>
  
     
        <?php     echo '<a href="users.php">Users</a>';  }
    ?>
    
  

</nav>
