<?php
session_start();
if(!isset($_SESSION["ID_doctor"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){
    if($_POST['do']=="update"){
        $id = $_POST["id"];

        $doctorId   = $_POST['doctorId'];
        $accepted=$_POST['accepted'];
    $stmt = $con->prepare("UPDATE appointment SET 
                                   doctorId = ?,
                                   accepted=?
                           WHERE appointmentId = ?");
   $stmt->execute(array($doctorId, $accepted, $id));
}if($_POST['do']=="delete"){
    $id = $_POST["id"];

    $stmt = $con->prepare("DELETE from  appointment  WHERE userId = ?");
   $stmt->execute(array( $id));
}



 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>USERS</title>
     <script src="https://kit.fontawesome.com/ec292494c9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

</head>
<body>


<?php  include('navbar.php'); 
$stmt = $con->prepare("SELECT * FROM patient where userId = ".$_GET['id']);
$stmt->execute( );
$rows = $stmt->fetch();
?>
<h1></h1>
<br><br>
<div class="profile_form">
 
<div class="table-responsive">
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div>
 
</div>

<div class="form">
<h1  style="text-align: center;"> User Info </h1>
            <div class="content" style="border: 1px solid black;">
          
                

                <form class="sign-up" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <input type="hidden" name="do" value="add">
                <input type="hidden" name="id" value="<?php echo $_GET['id']?>">
                    <!-- accept name contains 3 and more char -->
                    <label >First Name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="firstname"  readonly value="<?php echo $rows['firstName'] ?>" class="form-input" minlength="3" required>
<br>
                    <!-- required -->
                    <label >Last name <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="lastname" readonly value="<?php echo $rows['lastName'] ?>" class="form-input" required>
                    <br>

                    <label for="address">address <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="address" readonly value="<?php echo $rows['address'] ?>" id="address" class="form-input" required><br>
                    <label for="address">pirth Date <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="date" name="pirthDate" readonly  value="<?php echo $rows['pirh_date'] ?>" id="pirthDate" class="form-input" required><br>
                    <!-- matches password -->
                    <label for="phone">phone Number <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="phone" value="<?php echo $rows['phoneNum'] ?>" id="phone" class="form-input" required><br>
                    <label for="gender">gender <abbr title="This field is required" aria-label="required">*</abbr></label>
                    <input type="text" name="pirthDate" readonly  value="<?php echo $rows['gender'] ?>" id="pirthDate" class="form-input" required><br>

                 <br>

                </form>
            </div>
        </div>
        <?php $stmt = $con->prepare("SELECT a.*,p.firstName,p.lastName  FROM `appointment` a join patient p on p.userId=a.userId join patient d on d.userId=a.doctorId where a.userId =  ".$_GET['id']);
$stmt->execute( );
$rows = $stmt->fetchAll();
$stmt = $con->prepare("SELECT * FROM `patient`  where isAdmin = 2 ");
$stmt->execute( );
$doctors = $stmt->fetchAll(); ?>
        <h1 style="text-align: center;">List of appointments</h1>
        <table class="table" border="1" style="margin: auto; width: 100%;">
    <thead>
<tr>
    
    <th>Patient name</th>
 
    <th>Doctor</th>
    <th>Date</th>
    <th>time</th>
   <th>statu</th>
    <th>Update</th>

</tr>
    </thead>
    <tbody>
<?php foreach ($rows as $row) {?>
    <tr>
        <form action="" method="post">
<input type="hidden" name="do" value="update">

<input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">
    
    <td><?php echo $row['firstName'] ?> <?php echo $row['lastName'] ?></td>
 
    <td>
<select name="doctorId" class="form-control" >
<?php foreach ($doctors as $doc ) {?>
    <option value="<?php echo $doc['userId'] ?>"<?php if($row['doctorId']==$doc['userId']) echo 'selected' ?> ><?php echo $doc['firstName'].' '. $doc['lastName'] ?></option>
<?php }?>

</select> </td>
<td><?php echo date('Y-m-d', strtotime($row['date'])) ?></td>

<td> <?php echo date('H:i:s A', strtotime($row['date'])) ?>
    </td>           

   
   <td>
   <select name="accepted" class="form-control" >
<option value="0">In hold</option>
<option value="1" <?php if($row['accepted']==1)echo 'selected' ?>>Approved</option>
<option value="2" <?php if($row['accepted']==2)echo 'selected' ?>>Denied</option>

</select>
   </td>
   
    <td><button type="submit" class="btn btn-primary" >UPDATE</button></td>
 </form>
 <form action="" method="post">
 <input type="hidden" name="do" value="delete">
 <input type="hidden" name="id" value="<?php echo $row['appointmentId'] ?>">

 </form>
</tr>
    <?php } ?>
    </tbody>
  </table>
</div>

         


<!--footer-->


<footer class="footer-distributed">

    <div class="footer-left">


 



<?php include('footer.php'); ?>


</body>
</html>