<?php session_start();
if(!isset($_SESSION["ID_doctor"])){
    header('location: ../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    <meta charset="UTF-8">
    <title>Title</title>
    <script type="text/javascript"> (function() { var css = document.createElement('link'); css.href = 'https://use.fontawesome.com/releases/v5.1.0/css/all.css'; css.rel = 'stylesheet'; css.type = 'text/css'; document.getElementsByTagName('head')[0].appendChild(css); })(); </script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link href='../lib/main.css' rel='stylesheet' />
<script src='../lib/main.js'></script>
    <style>
        body {
            background-image: url('Mass Circles.svg');
        }
    </style>
</head>

<body>

<div  class="container" style="margin: 50px auto;">
<?php  include('navbar.php'); ?>
<?php  include '../connect.php';
 include '../functions.php';
      $stmt = $con->prepare("SELECT a.*,p.firstName,p.lastName, DATE_FORMAT(date, '%Y-%m-%dT%H:%i:%s') as cr  FROM appointment a join patient p on p.userId=a.userId WHERE doctorId =?");
                       $stmt->execute(array($_SESSION['ID_doctor']));
                       $jobs = $stmt->fetchAll(); 
                       $first =0;$val="";
                       foreach($jobs as $job)
                       {
                         $clas='';
                         if($first>0)
                         $clas=',';
                   
                         $val= "$val $clas { start:  '".$job["cr"]."' ,title: '". $job["firstName"]." ". $job["lastName"]."',color: '#0c823c'  }";
                       
                       $first++; }
                        ?>

                 <script>

document.addEventListener('DOMContentLoaded', function() {
  var calendarEl = document.getElementById('calendar');
  var today = new Date(); 
  const date = new Date();
date.setDate(date.getDate() + 1);
  var calendar = new FullCalendar.Calendar(calendarEl, {
    initialDate: today,
    editable: false,
    selectable: true,
    businessHours: false,
    dayMaxEvents: true, // allow "more" link when too many events
    events: [
<?php echo $val; ?>
    ]
  });

  calendar.render();
});

               </script>
               <style>
                   #calendar {
    max-width: 1100px;
    margin: 0 auto;
  }
               </style>

<div class="First_Part">

 
 
   
<div id='calendar'></div>




  

 
<br>
    <br>
  

    <script>
        // Get the modal
        let modal = document.getElementById('id02');

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <!--<section class="Sign_up">
        <form action="" method="post">

            <input type="text" placeholder="Email" id="email">
            <input type="password" placeholder="Password" id="password">
            <br>
            <br>
            <input type="submit" value="Sign up" class="sign_button" >

        </form>
    </section>-->


</div>

</div>

<?php include('footer.php'); ?>
</body>
</html>