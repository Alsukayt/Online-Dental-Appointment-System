<?php
session_start();
if(!isset($_SESSION["ID_doctor"])){
    header('location: ../index.php');
}
 include '../connect.php';
 include '../functions.php';
 if($_SERVER['REQUEST_METHOD'] == 'POST'){

 
 


 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../HomePage.css">
    
    <meta charset="UTF-8">
    <title>USERS</title>
     <script src="https://kit.fontawesome.com/ec292494c9.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"  crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightslider/1.1.6/css/lightslider.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="../Users.css">
    <style>
        body {
            background-image: url('Mass Circles.svg');
        }
    </style>
</head>
<body>


<?php  include('navbar.php'); 
$stmt = $con->prepare("SELECT * FROM patient where isAdmin = 0 ");//and p.userId in (select a.userId from appointment a where a.doctorId  =  ".$_SESSION['ID_doctor'].")
$stmt->execute( );
$rows = $stmt->fetchAll();
?>
<h1></h1>
<br><br>
<div class="profile_form" style="height: 100%;">
 <h1 style="text-align: center;">List of Patient</h1>
 
<div class="the-errors text-center">
            <?php  
            
                if(!empty($formErrors)){

                    foreach($formErrors as $error){

                        echo "<div class='masg error'>" . $error . "</div>";

                    }

                }

                if(isset($successMas)){

                    echo "<div class='masg success'>" . $successMas . "</div>";

                }

            ?>
        </div>



 
<?php foreach ($rows as $row) {?>
    <a href="user.php?id=<?php echo $row['userId']?>">
    <div class="Patient_card"  style="height:100%;margin-bottom: 50px">
    <section class="cards">
        <div class="content">
            <div class="cardS">
                <?php $picture=""; if($row['gender']=="male") $picture = "../undraw_male_avatar_323b.svg";
                else  $picture = "../undraw_female_avatar_w3jk.svg";?>
                <img class="Patient_pic" src="<?php echo $picture ?>" style="width: 60px;">
                <div class="info">
                    <label class="Title_name"><?php echo $row['firstName'] ?> <?php echo $row['lastName'] ?></label>
                </div>
            </div>

        </div>
    </section>
</div>     
 
</a>

 
    <?php } ?>
     
 
  
 
</div>

         
<br>
<h1>

</h1>
<br>
<!--footer-->
<?php

 if(isset($_POST['question'])){
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
     $email = $_POST['email'];
     $message = $_POST['message'];
     $stmt = $con->prepare("INSERT INTO question(`date`, question, email)
                                        VALUES(now(), :zquestion, :zemail)");
    $stmt->execute(array('zquestion' => $message, 'zemail' => $email));
    }
 }

?>

<footer class="footer-distributed">

    <div class="footer-left">

        <h3>Yake<span>System</span></h3>

        <p class="footer-links">
            <a href="HomePage.html">Home</a>
            ·
            <a href="Appointment.html">Appointment</a>
            ·
            <a href="patient.html">Patient</a>
            ·
            <a href="#">About</a>
            ·
            <a href="#">Contact</a>
        </p>
<?php
        require_once '../connect.php';
$stmt = $con->prepare("SELECT * FROM settings ");
$stmt->execute( );
$row = $stmt->fetch();
?>
        <div class="footer-icons">

            <a href="<?php echo $row['facebook']?>"><i class="fa fa-facebook"></i></a>
            <a href="<?php echo $row['twiter']?>"><i class="fa fa-twitter"></i></a>
            <a href="<?php echo $row['in_']?>"><i class="fa fa-linkedin"></i></a>
            <a href="<?php echo $row['git']?>"><i class="fa fa-github"></i></a>

        </div>

    </div>

    <div class="footer-right">

        <p>Contact Us</p>

        <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<input type="hidden" name="do">
            <input type="email" name="email" placeholder="Email">
            <textarea name="message" placeholder="Message"></textarea>
            <input type="submit" name="question" value="Send">

        </form>

    </div>
 
</footer>
<style>
    .footer-distributed{
        position: sticky;
    }
    </style>
</body>
</html>